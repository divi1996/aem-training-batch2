package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "STEP-ProductInformation")
public class STEPProductInformation {
    @JacksonXmlProperty(localName = "ExportContext",isAttribute = true)
    private String ExportContext;
    @JacksonXmlProperty(localName = "Assets")
    private Assets Assets;
    @JacksonXmlProperty(localName = "ExportTime",isAttribute = true)
    private String ExportTime;
    @JacksonXmlProperty(localName = "ContextID",isAttribute = true)
    private String ContextID;
    @JacksonXmlProperty(localName = "WorkspaceID",isAttribute = true)
    private String WorkspaceID;
    @JacksonXmlProperty(localName = "UseContextLocale",isAttribute = true)
    private String UseContextLocale;

    public String getExportContext ()
    {
        return ExportContext;
    }

    public void setExportContext (String ExportContext)
    {
        this.ExportContext = ExportContext;
    }

    public Assets getAssets ()
    {
        return Assets;
    }

    public void setAssets (Assets Assets)
    {
        this.Assets = Assets;
    }

    public String getExportTime ()
    {
        return ExportTime;
    }

    public void setExportTime (String ExportTime)
    {
        this.ExportTime = ExportTime;
    }

    public String getContextID ()
    {
        return ContextID;
    }

    public void setContextID (String ContextID)
    {
        this.ContextID = ContextID;
    }

    public String getWorkspaceID ()
    {
        return WorkspaceID;
    }

    public void setWorkspaceID (String WorkspaceID)
    {
        this.WorkspaceID = WorkspaceID;
    }

    public String getUseContextLocale ()
    {
        return UseContextLocale;
    }

    public void setUseContextLocale (String UseContextLocale)
    {
        this.UseContextLocale = UseContextLocale;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ExportContext = "+ExportContext+", Assets = "+Assets+", ExportTime = "+ExportTime+", ContextID = "+ContextID+", WorkspaceID = "+WorkspaceID+", UseContextLocale = "+UseContextLocale+"]";
    }
}
