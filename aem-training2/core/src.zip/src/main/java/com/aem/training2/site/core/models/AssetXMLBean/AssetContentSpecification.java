package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class AssetContentSpecification
{
    @JacksonXmlProperty(localName = "ImageConversionConfigurationID",isAttribute = true)
    private String ImageConversionConfigurationID;
    @JacksonXmlProperty(localName = "IncludesBinaryContent",isAttribute = true)
    private String IncludesBinaryContent;

    public String getImageConversionConfigurationID ()
    {
        return ImageConversionConfigurationID;
    }

    public void setImageConversionConfigurationID (String ImageConversionConfigurationID)
    {
        this.ImageConversionConfigurationID = ImageConversionConfigurationID;
    }

    public String getIncludesBinaryContent ()
    {
        return IncludesBinaryContent;
    }

    public void setIncludesBinaryContent (String IncludesBinaryContent)
    {
        this.IncludesBinaryContent = IncludesBinaryContent;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ImageConversionConfigurationID = "+ImageConversionConfigurationID+", IncludesBinaryContent = "+IncludesBinaryContent+"]";
    }
}
