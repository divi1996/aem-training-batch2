package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class AssetBinaryContent
{
    @JacksonXmlProperty(localName = "ImageConversionConfigurationID",isAttribute = true)
    private String ImageConversionConfigurationID;
    @JacksonXmlProperty(localName = "MIMEType",isAttribute = true)
    private String MIMEType;
    @JacksonXmlProperty(localName = "Checksum",isAttribute = true)
    private String Checksum;
    @JacksonXmlProperty(localName = "BinaryContent")
    private String BinaryContent;

    public String getImageConversionConfigurationID ()
    {
        return ImageConversionConfigurationID;
    }

    public void setImageConversionConfigurationID (String ImageConversionConfigurationID)
    {
        this.ImageConversionConfigurationID = ImageConversionConfigurationID;
    }

    public String getMIMEType ()
    {
        return MIMEType;
    }

    public void setMIMEType (String MIMEType)
    {
        this.MIMEType = MIMEType;
    }

    public String getChecksum ()
    {
        return Checksum;
    }

    public void setChecksum (String Checksum)
    {
        this.Checksum = Checksum;
    }

    public String getBinaryContent ()
    {
        return BinaryContent;
    }

    public void setBinaryContent (String BinaryContent)
    {
        this.BinaryContent = BinaryContent;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [ImageConversionConfigurationID = "+ImageConversionConfigurationID+", MIMEType = "+MIMEType+", Checksum = "+Checksum+", BinaryContent = "+BinaryContent+"]";
    }
}