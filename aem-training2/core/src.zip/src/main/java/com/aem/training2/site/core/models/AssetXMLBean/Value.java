package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

public class Value {
    @JacksonXmlProperty(localName = "UnitID")
    private String UnitID;
    @JacksonXmlProperty(localName = "AttributeID", isAttribute = true)
    private String AttributeID;
    @JacksonXmlText
    private String content;

    public String getUnitID() {
        return UnitID;
    }

    public void setUnitID(String UnitID) {
        this.UnitID = UnitID;
    }

    public String getAttributeID() {
        return AttributeID;
    }

    public void setAttributeID(String AttributeID) {
        this.AttributeID = AttributeID;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ClassPojo [UnitID = " + UnitID + ", AttributeID = " + AttributeID + ", content = " + content + "]";
    }
}
