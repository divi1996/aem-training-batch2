package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class AssetContent
{
    @JacksonXmlProperty(localName = "AssetContentSpecification")
    private AssetContentSpecification AssetContentSpecification;

    public AssetContentSpecification getAssetContentSpecification ()
    {
        return AssetContentSpecification;
    }

    public void setAssetContentSpecification (AssetContentSpecification AssetContentSpecification)
    {
        this.AssetContentSpecification = AssetContentSpecification;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [AssetContentSpecification = "+AssetContentSpecification+"]";
    }
}
