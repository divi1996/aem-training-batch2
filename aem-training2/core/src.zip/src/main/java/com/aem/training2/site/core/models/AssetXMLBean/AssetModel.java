package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class AssetModel {
    @JacksonXmlProperty(localName = "STEP-ProductInformation")
    private STEPProductInformation STEPProductInformation;

    public STEPProductInformation getSTEPProductInformation() {
        return STEPProductInformation;
    }

    public void setSTEPProductInformation(STEPProductInformation STEPProductInformation) {
        this.STEPProductInformation = STEPProductInformation;
    }

    @Override
    public String toString() {
        return "ClassPojo [STEP-ProductInformation = " + STEPProductInformation + "]";
    }
}
