package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class Assets
{
    @JacksonXmlProperty(localName = "Asset")
    private Asset Asset;

    public Asset getAsset ()
    {
        return Asset;
    }

    public void setAsset (Asset Asset)
    {
        this.Asset = Asset;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [Asset = "+Asset+"]";
    }
}

