/*
 *  Copyright 2015 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.aem.training2.site.core.servlets;

import com.aem.training2.site.core.models.AssetXMLBean.AssetBinaryContent;
import com.aem.training2.site.core.models.AssetXMLBean.STEPProductInformation;
import com.aem.training2.site.core.models.AssetXMLBean.Value;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.JsonObject;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.entity.ContentType;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.*;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.xml.bind.DatatypeConverter;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component(
        service = Servlet.class,
        property = {Constants.SERVICE_DESCRIPTION + "=Asset creation servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_POST,
                "sling.servlet.paths=" + "/bin/createxml"})
public class XMLtoAssetServlet extends SlingAllMethodsServlet {

    public static final String IMAGE_XML = "imageXml";
    public static final String ASSET_EXTENSION = "asset.extension";
    private final Logger LOG = LoggerFactory.getLogger(XMLtoAssetServlet.class);
    private static final long serialVersionUID = 1L;
    public static final String ASSET_PATH = "/content/dam/training/";
    public static final String METADATA_PATH = "/" + JcrConstants.JCR_CONTENT + "/metadata";
    private String imageXmlString = StringUtils.EMPTY;
    ResourceResolver resolver = null;
    ResponseCodes responseCode = null;

    @Reference
    Replicator replicator;

    private enum ResponseCodes {
        CreateFailed(-7, "No write permissions"),
        AuthorModeOnly(-6, "Request allowed only for author mode, Please check the URL"),
        PublishFailed(-5, "Asset created.Failed to publish asset"),
        InvalidMimeType(-4, "Incorrect mime-type"),
        ImageTooLarge(-3, "Max. size exceeded"),
        UseExceptionMsg(-1, null), //use exception.getMessage() as we are catching a generic Exception when this is used
        MissingRequiredParams(-1, "Invalid request missing mandatory request form data"),
        InternalServerError(-1, "Internal Server Error"),
        ErrorAddingMetadata(-1, "Error Adding Metadata Properties"),
        AssetAlreadyExists(-1,"Asset already exists at same location and name"),
        AssetCreated(0, "Asset Added"),;

        private int id;
        private String msg;

        ResponseCodes(int x, String status) {
            this.id = x;
            this.msg = status;
        }
    }

    @Override
    protected void doPost(final SlingHttpServletRequest req,
                          final SlingHttpServletResponse resp) throws ServletException, IOException {
        try {
            readFormData(req);
            resolver = req.getResourceResolver();
            XmlMapper xmlMapper = new XmlMapper();
            STEPProductInformation value = xmlMapper.readValue(imageXmlString, STEPProductInformation.class);
            if (Objects.nonNull(resolver) && Objects.nonNull(value)) {
                createAsset(value);
            } else {
                responseCode = ResponseCodes.CreateFailed;
            }
            System.out.println("hello");
        } catch (Exception e) {
            responseCode = ResponseCodes.InternalServerError;
            LOG.error("Exception in creating asset :: Exception is {}", e);
        }finally {
            JsonObject json = new JsonObject();
            json.addProperty("code",responseCode.id);
            json.addProperty("message",responseCode.msg);
            resp.setContentType(ContentType.APPLICATION_JSON.getMimeType());
            resp.setCharacterEncoding(ContentType.APPLICATION_JSON.getCharset().toString());
            resp.getWriter().println(json.toString());
        }
    }

    private Asset createAsset(STEPProductInformation xmlObject) {
        Asset asset = null;
        if (isValidObject(xmlObject)) {
            AssetBinaryContent binaryContent = xmlObject.getAssets().getAsset().getAssetBinaryContent();
            String mimeType = binaryContent.getMIMEType();
            String id = xmlObject.getAssets().getAsset().getID();
            String imageString = binaryContent.getBinaryContent();
            Map<String, String> props = getImageProperties(xmlObject);
            String extension = props.get(ASSET_EXTENSION);
            byte[] imageBytes = DatatypeConverter.parseBase64Binary(imageString);
            InputStream targetStream = new ByteArrayInputStream(imageBytes);
            AssetManager assetManager = resolver.adaptTo(AssetManager.class);
            String path = getAssetPath(id, extension);
            if (!isAlreadyCreated(path)) {
                asset = assetManager.createAsset(path, targetStream, mimeType, true);
                if (Objects.nonNull(asset) && !props.isEmpty()) {
                    responseCode = ResponseCodes.AssetCreated;
                    publishAsset(asset.getPath());
                    addMetaProperties(asset, props);
                }
            }else {

            }
        } else {
            responseCode = ResponseCodes.MissingRequiredParams;
        }
        return asset;
    }

    private Boolean isAlreadyCreated(String assetPath) {
        Resource res = resolver.getResource(assetPath);
        return Objects.nonNull(res);
    }

    private Boolean isValidObject(STEPProductInformation xmlObject) {
        return (Objects.nonNull(xmlObject.getAssets()) &&
                Objects.nonNull(xmlObject.getAssets().getAsset()) &&
                Objects.nonNull(xmlObject.getAssets().getAsset().getAssetBinaryContent()) &&
                Objects.nonNull(xmlObject.getAssets().getAsset().getAssetBinaryContent().getMIMEType()) &&
                StringUtils.isNotBlank(xmlObject.getAssets().getAsset().getAssetBinaryContent().getBinaryContent()));
    }

    private void addMetaProperties(Asset asset, Map<String, String> props) {
        Resource res = resolver.getResource(asset.getPath() + METADATA_PATH);
        ModifiableValueMap map = res.adaptTo(ModifiableValueMap.class);
        map.put("format", props.get("asset.format"));
        try {
            res.getResourceResolver().commit();
        } catch (PersistenceException e) {
            responseCode = ResponseCodes.ErrorAddingMetadata;
        }
    }

    private Map<String, String> getImageProperties(STEPProductInformation xmlObject) {
        Value[] metadataValues = xmlObject.getAssets().getAsset().getValues().getValue();
        Map<String, String> propertiesMap = new HashMap<>();
        for (Value val : metadataValues) {
            propertiesMap.put(val.getAttributeID(), val.getContent());
        }
        return propertiesMap;
    }

    private Calendar parseDate(String inputDate) throws ParseException {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(inputDate);
        SimpleDateFormat newDate = new SimpleDateFormat("YYY-MM-DDTHH:mm:ss");
        newDate.format(date);
        cal.setTime(date);
        return cal;
    }

    private String getAssetPath(String id, String extension) {
        return ASSET_PATH.concat(id).concat(".").concat(extension);
    }

    private void readFormData(SlingHttpServletRequest request) {
        final boolean isMultipart = ServletFileUpload.isMultipartContent(request);
        try {
            if (isMultipart) {
                Map<String, RequestParameter[]> params = request.getRequestParameterMap();
                for (final Map.Entry<String, RequestParameter[]> pairs : params.entrySet()) {
                    final String key = pairs.getKey();
                    final RequestParameter[] pArr = pairs.getValue();
                    final RequestParameter param = pArr[0];
                    if (key.equalsIgnoreCase(IMAGE_XML)) {
                        imageXmlString = param.getString();
                    }
                }
            }
        } catch (Exception e) {
            LOG.error("Exception in readFormData: {}", e.getMessage(), e);
        }
    }

    private void publishAsset(String assetPath) {
        Session session = resolver.adaptTo(Session.class);
        try {
            replicator.replicate(session, ReplicationActionType.ACTIVATE, assetPath);
        } catch (ReplicationException e) {
            responseCode = ResponseCodes.PublishFailed;
        }
    }
}
