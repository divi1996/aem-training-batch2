package com.aem.training2.site.core.models.AssetXMLBean;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class Asset {
    @JacksonXmlProperty(localName = "ClassificationReference")
    @JacksonXmlElementWrapper(useWrapping = false)
    private ClassificationReference[] ClassificationReference;
    @JacksonXmlProperty(localName = "UserTypeID", isAttribute = true)
    private String UserTypeID;
    @JacksonXmlProperty(localName = "AssetContent")
    private AssetContent AssetContent;
    @JacksonXmlProperty(localName = "Values")
    private Values Values;
    @JacksonXmlProperty(localName = "ID", isAttribute = true)
    private String ID;
    @JacksonXmlProperty(localName = "AssetBinaryContent")
    private AssetBinaryContent AssetBinaryContent;

    public ClassificationReference[] getClassificationReference() {
        return ClassificationReference;
    }

    public void setClassificationReference(ClassificationReference[] ClassificationReference) {
        this.ClassificationReference = ClassificationReference;
    }

    public String getUserTypeID() {
        return UserTypeID;
    }

    public void setUserTypeID(String UserTypeID) {
        this.UserTypeID = UserTypeID;
    }

    public AssetContent getAssetContent() {
        return AssetContent;
    }

    public void setAssetContent(AssetContent AssetContent) {
        this.AssetContent = AssetContent;
    }

    public Values getValues() {
        return Values;
    }

    public void setValues(Values Values) {
        this.Values = Values;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public AssetBinaryContent getAssetBinaryContent() {
        return AssetBinaryContent;
    }

    public void setAssetBinaryContent(AssetBinaryContent AssetBinaryContent) {
        this.AssetBinaryContent = AssetBinaryContent;
    }

    @Override
    public String toString() {
        return "ClassPojo [ClassificationReference = " + ClassificationReference + ", UserTypeID = " + UserTypeID + ", AssetContent = " + AssetContent + ", Values = " + Values + ", ID = " + ID + ", AssetBinaryContent = " + AssetBinaryContent + "]";
    }
}
